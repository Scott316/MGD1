//aSprite class based on lab
class aSprite{
constructor(x, y, imageSRC, velx, vely, spType){
this.zindex = 0;
this.x = x;
this.y = y;
this.vx = velx;
this.xy = vely;
this.sType = spType;
this.sImage = new Image();
this.sImage.src = imageSRC;
}
//Getter
get xPos(){
return this.x;
}

get yPos(){
return this.y;
}

//Setter
set xPos(newX){
this.x = newX;
}

set yPos(newY){
this.y = newY;
}

//Method
render()
{
canvasContext.drawImage(this.sImage, this.x, this.y);
}
//Method
scrollBK (delta)
{
//var xPos = delta * this.vx;

canvasContext.save();
canvasContext.translate(-delta, 0);
canvasContext.drawImage(this.sImage, 0, 0);
canvasContext.drawImage(this.sImage, this.sImage.width, 0);
canvasContext.restore();
}
//Method
sPos(newX, newY){
this.x = newX;
this.y = newY;
}

//Static Method
static distance(a, b){
const dx = a.x - b.x;
const dy = a.y - b.y;

return Math.hypot(dx, dy);
}

//Method
spriteType(){
console.log('I am a ' + this.sType + ' instance of aSprite!!!!!!!!!!!!!!!');
}
}
//end of aSprite class from labs
//from labs
var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

window.requestAnimationFrame = requestAnimationFrame;

var canvasContext
var canvas = document.getElementById("gameCanvas");
//sets the width of the canvas width to 1400 pixels
var width = 1400;
//sets the height of the canvas width to 700 pixels
var height = 700;
var ctx = canvas.getContext("2d");
var player = {
x: width / 2,
y: height / 1.65,
width: 100,
height: 100,
velX: 0,
velY: 0
};
var soundMgr;
var enemy = {
x: width / 1,
y: height / 1.65,
width: 100,
height: 100,
velX: 0,
velY: 0
};
var collectible = {
x: width /1.5,
y: height / 1.65,
width: 100,
height: 100
};

var keys = [];
var friction = 0.8;
var themeMusic;
var soundEffect;
var startTimeMS = 0;
var frameX = 0;
var frameXMax = 3;
var frameY = 0;
var frameYMax = 4;
var frame = 0;
var frameMax = 9;
var frameTimer = 0.18;
var frameTimeMax = 0.2;
var spriteWidth = 183;
var spriteHeight = 330;
var enemySpritewidth = 307;
var enemySpriteHeight = 485;
var img = new Image();
var enemyimg = new Image();
var isKeyPressed = false;
var level = 5;
//USED FOR THE TIMER, EXTENSION MATERIAL////////////////////////////////////////
//sets the amount of time on the timer at the start
const minutesAtStart = 2;
//counts every second involved in the two minutes
let time = minutesAtStart * 60;
//sets up the countdown timer
const countdownTimer = document.getElementById('countdown timer');
//END OF EXTENSION MATERIAL ATTEMPT//////////////////////////////////////////////
//sets up a constant variable for the score at the start of the game and makes it equal to 0
const scoreAtStart = 0;
//sets the scoreUI variable to equal the element on the canvas with the id "score"
const scoreUI = document.getElementById('score');
//sets the variable scoreAmount to equal 0
var scoreAmount = 0;
//sets the update score method to be called every second
setInterval(updateScore, 1000);
//these are for the menu===========================================================================
var buttonX = [550, 700, 550, 700];
var buttonY = [350, 350, 350, 350];
var buttonWidth = [100, 100, 100, 100];
var buttonHeight = [100, 100, 100, 100];

var mouseX;
var mouseY;

var replayButton = new Image();
var playImage = new Image();
var quit = new Image();
var WASD = new Image();
var AlexanderMenu = new Image();
var ElleMenu = new Image();
var buttonClicked;
//====================================================================================================
function updateScore()
{
//sets the content of the score ui to display the score
scoreUI.innerHTML = `${scoreAmount}`;
}
function load() {
console.log("tests");
}

window.addEventListener("load", function () {
init();
showMenu();
});

function init()
{
   canvas.width = width;
   canvas.height = height;
   buttonClicked = 0;
   if(soundMgr != null) soundMgr.playMusic(0);
}

document.body.addEventListener("keydown", function (e) {
keys[e.keyCode] = true;
isKeyPressed = true;
});

document.body.addEventListener("keyup", function (e) {
keys[e.keyCode] = false;
isKeyPressed = false;
});

function startGame() {
img.src = 'Elle.png';
enemyimg.src = 'Alexander.png';
soundEffect = new sound("Yoda.mp3")
themeMusic = new sound("Circle Of Life.mp3");

//plays the theme music
themeMusic.play();
if (canvas.getContext)
   {

     window.addEventListener("touchstart", touchingDown, false);
     window.addEventListener("touchmove", touchXY, true);
     window.addEventListener("touchend", touchUp, false);
   }

   update();
   //COUNTDOWN TIMER /////////////////////////////////////////////////////////////
   //calls the update timer function every second after the game has started
   setInterval(updateTimer, 1000);
   //END OF COUNTDOWN TIMER ///////////////////////////////////////////////////////////////////
}

//COUNTDOWN TIMER ///////////////////////////////////////////////////////////////
function updateTimer(){
//sets the minute counter to return the largest number of the remaining time divided by 60
const minuteCounter = Math.floor(time/60);
//sets the seconds to equal the value left after the division
let seconds = time % 60;
//if the value on the seconds side is less than 10, a 0 will appear before the seconds value
//eg. "1:09"
seconds = seconds < 10 ? '0' + seconds : seconds;
//sets the values that is shown in the counter to equal the values of the minute counter and the secons
countdownTimer.innerHTML = `${minuteCounter}: ${seconds}`;
if(minuteCounter != -1 && seconds != -1)
{
time--;
}
if (minuteCounter == 0 & seconds == 0)
{
if(health.value > localStorage.getItem("health"))
{
localStorage.setItem("health", health.value);
}
window.close();
}
}
//END OF COUNTDOWN TIMER/////////////////////////////////////////////////////////
function update() {
ctx.clearRect(0, 20, width, height);
//displays the health value in the console log
console.log(health.value);
//if the ESCAPE key is pressed
if (keys[27])
{
//the web browser window is closed
window.close();
}

//if the S button is pressed and the player is within the vertical position range,
if (keys[83] && player.y < (canvas.height - player.height - 100)) {
//the player will move down the screen
player.velY++;
}

//if the W key is pressed and the
if (keys[87] && player.y > 405) {
player.velY--;
player.y--;
}

//if the D button is pressed,
if (keys[68] && player.x < (canvas.width - player.width - 20)) {
//the player will be moved towards the right of the screen
player.velX++;
player.x ++;
}
//if the A button is pressed,
if (keys[65] && player.x > player.width) {
//the player will be moved towards the left of the screen
player.velX--;
player.x --;
}
//if the pause/play button is pressed,
if (keys[179]){
//the theme music will stop
themeMusic.stop();
}

player.velX *= friction;
player.velY *= friction;
player.x += player.velX;
player.y += player.velY;


//if the movement keys are pressed,
if (keys[65] || keys[68] || keys[83] || keys[87]) {
//the animation frame method will be called
animationFrame();
//and the animation spritesheet will be played
ctx.drawImage(img, spriteWidth * frameX, spriteHeight * frameY, spriteWidth, spriteHeight, player.x, player.y, player.width, player.height);
scoreAmount += 5;
//EXTENSION WORK*****************************************
//If the current is larger than the currently saved high score,
if(scoreAmount > localStorage.getItem("high score"))
{
//the new score is saved as the high score.
localStorage.setItem("high score", scoreAmount);
}
//END OF EXTENSION WORK*********************************
} else
ctx.drawImage(img, spriteWidth * 2, spriteHeight * 1, spriteWidth, spriteHeight, player.x, player.y, player.width, player.height);

if (enemy.x > enemy.width) {
animationFrame();
ctx.drawImage(enemyimg, enemySpritewidth * frameX, enemySpriteHeight * frameY, enemySpritewidth, enemySpriteHeight, enemy.x, enemy.y, enemy.width, enemy.height);
enemy.velX--;
} else {
ctx.drawImage(enemyimg,  enemySpritewidth * 2, enemySpriteHeight * 1,  enemySpritewidth, enemySpriteHeight, enemy.x, enemy.y, enemy.width, enemy.height);
}
enemy.velX *= friction;
enemy.velY *= friction;
enemy.x += enemy.velX;
enemy.y += enemy.velY;
ctx.beginPath();
ctx.lineWidth = "4";
ctx.strokeStyle = "green";
ctx.rect(player.x, player.y, player.width, player.height);
ctx.stroke();

//draws a green box around the enemy that will be used for checking collisions
ctx.beginPath();
ctx.lineWidth = "4";
ctx.strokeStyle = "green";
ctx.rect(enemy.x, enemy.y, enemy.width, enemy.height);
ctx.stroke();

var dir = colCheck(player, enemy);
//if a collision has taken place,
if(dir) {
//the console will display a message informing the user of the collision
console.log("player collide with enemy");
//if the health value is more than 0
if (health.value > 0)
{
//0.5 points will be depleted and
health.value -=0.5;
//it subtracts 100 points from the score
scoreAmount -= 100;
//the sound effect will play
soundEffect.play();
}
//if the player runs out of health,
if (health.value <= 0)
{
if (time < localStorage.getItem("time"))
{
localStorage.setItem("time", time/60);
}
showGameOverScreen();
}
}
requestAnimationFrame(update);
}

function sound(src) {
  this.sound = document.createElement("audio");
  this.sound.src = src;
  this.sound.setAttribute("preload", "auto");
  this.sound.setAttribute("controls", "none");
  this.sound.style.display = "none";
  document.body.appendChild(this.sound);
  this.play = function(){
    this.sound.play();
  }
  this.stop = function(){
    this.sound.pause();
  }
}

function animationFrame() {
var elapsed = (Date.now() - startTimeMS) / 1000;
startTimeMS = Date.now();

//only update frames when timer is below 0
frameTimer = frameTimer - elapsed;
if (frameTimer <= 0) {
frameTimer = frameTimeMax;
frameX++;
if (frameX > frameXMax) {
frameX = 0;
frameY++;
//end of row, move down to next row in sheet
if (frameY > frameYMax) {
frameY = 0;
}
}
frame++;
//reset frames to 0 in event that there are empty spaces on sprite sheet
if (frame > frameMax) {
frame = 0;
frameX = 0;
frameY = 0;
}
}
}

function touchUp(evt)
{
   evt.preventDefault();

   var touchX = evt.touches[0].pageX - canvas.offsetLeft;
   var touchY = evt.touches[0].pageY - canvas.offsetTop;

   lastPt = null;
}

function touchingDown(evt)
{
    evt.preventDefault();
    touchXY(evt);
}

function touchXY(evt)
{
   evt.preventDefault();
   if (lastPt!=null)
   {
      var touchX = evt.touches[0].pageX - canvas.offsetLeft;
      var touchY = evt.touches[0].pageY - canvas.offsetTop;
      player.x = touchX - (player.width / 8);
   }
   lastPt = {x:evt.touches[0].pageX, y:evt.touches[0].pageY};
}

function showMenu(){
playImage.src = "playbutton.png";
playImage.addEventListener('load', e => {
ctx.drawImage(playImage, buttonX[0], buttonY[0], buttonWidth[0], buttonHeight[0]);
});

WASD.src = "WASD.jpg";
WASD.addEventListener('load', e => {
ctx.drawImage(WASD, 450, 50, 150, 100)});

ctx.font = "30px Comic Sans MS";
ctx.fillStyle = "yellow";
ctx.textAlign - "center";
ctx.fillText("Tit-elle In Progress", 550, 30);
ctx.fillText(" - Moves the character", 600, 100);
ctx.fillText(" - Main enemy", 160, 260);
ctx.fillText(" - Main player", 560, 260);

AlexanderMenu.src = "Alexander Menu.png";
AlexanderMenu.addEventListener('load', e => {
ctx.drawImage(AlexanderMenu, 50, 200, 150, 100)});

ElleMenu.src="ElleMenu.png";
ElleMenu.addEventListener('load', e => {
ctx.drawImage(ElleMenu, 450, 200, 150, 100)});

quit.src = "quitbutton.png";
quit.addEventListener('load', e => {
ctx.drawImage(quit, buttonX[1], buttonY[1], buttonWidth[1], buttonHeight[1]);
});
canvas.addEventListener("mousemove", checkPos);
canvas.addEventListener("mouseup", checkClick);
};

function checkPos(event){
coords = canvas.relMouseCoords(event);
mouseX = coords.x;
mouseY = coords.y;
}


HTMLCanvasElement.prototype.relMouseCoords = function(event){
var totalOffsetX = 0;
var totalOffsetY = 0;
var canvasX = 0;
var canvasY = 0;
var currentElement = this;

do{
totalOffsetX += currentElement.offsetLeft;
totalOffsetY += currentElement.offsetTop;
}
while (currentElement = currentElement.offsetParent)

canvasX = event.pageX - totalOffsetX;
canvasY = event.pageY - totalOffsetY;

//fix for variable canvas width
canvasX = Math.round( canvasX * (this.width / this.offsetWidth));
canvasY = Math.round( canvasY * (this.height / this.offsetHeight));

return {x:canvasX, y:canvasY};
}

function checkClick(mouseEvent){
if(mouseX > buttonX[0] && mouseX < (buttonX[0] + buttonWidth[0])){
if(mouseY > buttonY[0] && mouseY < (buttonY[0] + buttonHeight[0]) ) {
buttonClicked = 1;
startGame();
}
}

if(mouseX > buttonX[1] && mouseX < (buttonX[1] + buttonWidth[1])){
if(mouseY > buttonY[1] && mouseY < (buttonY[1] + buttonHeight[1]) ) {
buttonClicked = 2;
quitGame();
}
}

if(mouseX > buttonX[2] && mouseX < (buttonX[2] + buttonWidth[1])){
if(mouseY > buttonY[2] && mouseY < (buttonY[2] + buttonHeight[1]) ) {
buttonClicked = 3;
replay();
}
}

if(mouseX > buttonX[3] && mouseX < (buttonX[3] + buttonWidth[1])){
if(mouseY > buttonY[3] && mouseY < (buttonY[3] + buttonHeight[1]) ) {
buttonClicked = 4;
quitGame();
}
}
 if(buttonClicked>0){
 canvas.removeEventListener("mousemove", checkPos);
 canvas.removeEventListener("mouseup", checkClick);
 }
}

function colCheck(shapeA, shapeB){
//get the vectors to check against
var vX = (shapeA.x + (shapeA.width/2)) - (shapeB.x + (shapeB.width / 2)),
    vY = (shapeA.y + (shapeA.height /2)) - (shapeB.y + (shapeB.height /2)),
    //add the half widths and half heights of the objects
    hWidths = (shapeA.width / 2) + (shapeB.width / 2),
    hHeights = (shapeA.height / 2) + (shapeB.height /2),
    colDir = null;

    //if the x and y vector are less than the half width or half height, then we must be inside the object
    if (Math.abs(vX) < hWidths && Math.abs(vY) < hHeights){
    colDir = true;
    }
    return colDir;
}
function showGameOverScreen()
{
ctx.clearRect(0, 20, width, height);
ctx.font = "30px Comic Sans MS";
ctx.fillStyle = "yellow";
ctx.textAlign - "center";
ctx.fillText("Game Over!!!!!!!!!!!!!!!!!!", 550, 30);
ctx.fillText(" YOU DIED", 600, 100);
ctx.fillText("Player Score: " + scoreAmount, 560, 260);
themeMusic.stop();
replayButton.src = "Replay.jpg";
replayButton.addEventListener('load', e => {
ctx.drawImage(replayButton, buttonX[2], buttonY[2], buttonWidth[2], buttonHeight[2]);
});
quit.src = "quitbutton.png";
quit.addEventListener('load', e => {
ctx.drawImage(quit, buttonX[3], buttonY[3], buttonWidth[3], buttonHeight[3]);
});
canvas.addEventListener("mousemove", checkPos);
canvas.addEventListener("mouseup", checkClick);
clearInterval(interval);

}


function replay()
{
  showMenu();
}

function quitGame(){
//the game stops and the window closes
window.close();
}